<?php
session_start();

// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'bchi_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// OAuth Configuration
define('GOOGLE_CLIENT_ID', 'your-google-client-id');
define('GOOGLE_CLIENT_SECRET', 'your-google-client-secret');
define('GOOGLE_REDIRECT_URI', 'http://localhost/auth/google-callback.php');

define('GITHUB_CLIENT_ID', 'your-github-client-id');
define('GITHUB_CLIENT_SECRET', 'your-github-client-secret');
define('GITHUB_REDIRECT_URI', 'http://localhost/auth/github-callback.php');

define('FACEBOOK_APP_ID', 'your-facebook-app-id');
define('FACEBOOK_APP_SECRET', 'your-facebook-app-secret');
define('FACEBOOK_REDIRECT_URI', 'http://localhost/auth/facebook-callback.php');

// Database connection
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    error_log("Connection failed: " . $e->getMessage());
    die("Connection failed. Please try again later.");
}

// Authentication functions
function login($email, $password) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("CALL sp_login(?, ?, ?)");
        $stmt->execute([
            $email,
            password_hash($password, PASSWORD_DEFAULT),
            $_SERVER['REMOTE_ADDR']
        ]);
        
        $user = $stmt->fetch();
        
        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['last_activity'] = time();
            
            return [
                'success' => true,
                'user' => $user
            ];
        }
    } catch (PDOException $e) {
        error_log("Login error: " . $e->getMessage());
        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
    
    return [
        'success' => false,
        'message' => 'Invalid email or password'
    ];
}

function register($firstName, $lastName, $email, $password) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("CALL sp_register(?, ?, ?, ?, ?)");
        $stmt->execute([
            $firstName,
            $lastName,
            $email,
            password_hash($password, PASSWORD_DEFAULT),
            $_SERVER['REMOTE_ADDR']
        ]);
        
        $user = $stmt->fetch();
        
        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['last_activity'] = time();
            
            return [
                'success' => true,
                'user' => $user
            ];
        }
    } catch (PDOException $e) {
        error_log("Registration error: " . $e->getMessage());
        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
    
    return [
        'success' => false,
        'message' => 'Registration failed'
    ];
}

function socialLogin($provider, $providerData) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("CALL sp_social_login(?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $provider,
            $providerData['id'],
            $providerData['email'],
            $providerData['first_name'],
            $providerData['last_name'],
            $providerData['access_token'],
            $_SERVER['REMOTE_ADDR']
        ]);
        
        $user = $stmt->fetch();
        
        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['last_activity'] = time();
            
            return [
                'success' => true,
                'user' => $user
            ];
        }
    } catch (PDOException $e) {
        error_log("Social login error: " . $e->getMessage());
        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
    
    return [
        'success' => false,
        'message' => 'Social login failed'
    ];
}

function createRememberToken($userId) {
    global $pdo;
    
    $token = bin2hex(random_bytes(32));
    $expiry = date('Y-m-d H:i:s', strtotime('+30 days'));
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO remember_tokens (user_id, token, expires_at)
            VALUES (?, ?, ?)
        ");
        
        $stmt->execute([$userId, $token, $expiry]);
        
        setcookie('remember_token', $token, time() + (86400 * 30), '/', '', true, true);
        
        return true;
    } catch (PDOException $e) {
        error_log("Remember token error: " . $e->getMessage());
        return false;
    }
}

function checkRememberToken() {
    global $pdo;
    
    if (isset($_COOKIE['remember_token'])) {
        try {
            $stmt = $pdo->prepare("
                SELECT u.* FROM users u
                JOIN remember_tokens r ON u.id = r.user_id
                WHERE r.token = ? AND r.expires_at > NOW()
            ");
            
            $stmt->execute([$_COOKIE['remember_token']]);
            $user = $stmt->fetch();
            
            if ($user) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['last_activity'] = time();
                
                return true;
            }
        } catch (PDOException $e) {
            error_log("Remember token check error: " . $e->getMessage());
        }
    }
    
    return false;
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function logout() {
    global $pdo;
    
    if (isset($_SESSION['user_id'])) {
        try {
            // Log the logout
            $stmt = $pdo->prepare("
                INSERT INTO activity_logs (user_id, action, ip_address)
                VALUES (?, 'logout', ?)
            ");
            $stmt->execute([$_SESSION['user_id'], $_SERVER['REMOTE_ADDR']]);
            
            // Remove remember token if exists
            if (isset($_COOKIE['remember_token'])) {
                $stmt = $pdo->prepare("DELETE FROM remember_tokens WHERE token = ?");
                $stmt->execute([$_COOKIE['remember_token']]);
                setcookie('remember_token', '', time() - 3600, '/');
            }
        } catch (PDOException $e) {
            error_log("Logout error: " . $e->getMessage());
        }
        
        // Clear session
        session_unset();
        session_destroy();
    }
}

// Session security
function regenerateSession() {
    if (!isset($_SESSION['last_regeneration']) || 
        time() - $_SESSION['last_regeneration'] >= 1800) {
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }
}

// Check session timeout
if (isset($_SESSION['last_activity']) && time() - $_SESSION['last_activity'] > 1800) {
    logout();
    header('Location: /auth.html');
    exit();
}

$_SESSION['last_activity'] = time();
regenerateSession();

// Check remember me token
if (!isLoggedIn()) {
    checkRememberToken();
}

// CSRF Protection
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function validateCSRF($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
