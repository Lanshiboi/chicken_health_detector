<?php
require_once 'includes/config.php';

// Test database connection
try {
    $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Database connection successful!\n";
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Test file structure
$required_files = [
    'index.html',
    'dashboard.html',
    'analyze.html',
    'assets/css/style.css',
    'assets/js/main.js',
    'database.sql',
    'includes/config.php'
];

foreach ($required_files as $file) {
    if (file_exists($file)) {
        echo "$file exists and is readable\n";
    } else {
        echo "Warning: $file is missing!\n";
    }
}

// Test upload directory
$upload_dir = 'uploads/images';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
    echo "Created upload directory: $upload_dir\n";
}

echo "\nSystem setup complete and ready for use!";
?>
