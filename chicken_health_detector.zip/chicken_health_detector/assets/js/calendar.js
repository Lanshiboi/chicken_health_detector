document.addEventListener('DOMContentLoaded', function() {
    // Initialize calendar
    const calendarEl = document.getElementById('calendar');
    if (!calendarEl) return;

    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        events: loadEvents,
        eventClick: handleEventClick,
        dateClick: handleDateClick,
        eventDidMount: function(info) {
            // Add tooltips
            new bootstrap.Tooltip(info.el, {
                title: info.event.extendedProps.description || info.event.title,
                placement: 'top',
                trigger: 'hover',
                container: 'body'
            });
        }
    });

    calendar.render();

    // Listen for analysis updates
    document.addEventListener('analysisUpdated', function() {
        calendar.refetchEvents();
    });

    function loadEvents(info, successCallback) {
        const events = [];
        
        try {
            // Load analyses from localStorage
            const analyses = JSON.parse(localStorage.getItem('analyses') || '[]');
            
            // Get unique chicken IDs from analyses
            const chickenIds = [...new Set(analyses.map(a => a.chickenId || ''))].filter(id => id);
            
            // If no chicken IDs found, create default ones
            if (chickenIds.length === 0) {
                for (let i = 1; i <= 5; i++) {
                    chickenIds.push(`Chicken ${i}`);
                }
            }

            // Convert analyses to events
            analyses.forEach(analysis => {
                events.push({
                    title: `Analysis: ${analysis.chickenId || 'Unknown'} - ${analysis.status}`,
                    start: analysis.date,
                    className: getEventClass(analysis.status),
                    extendedProps: {
                        type: 'analysis',
                        analysis: analysis,
                        chickenId: analysis.chickenId,
                        description: `${analysis.chickenId || 'Unknown'}: ${analysis.details?.[0] || 'No details available'}`
                    }
                });
            });

            // Add health checks for each chicken
            chickenIds.forEach(chickenId => {
                const today = new Date();
                for (let i = 0; i < 30; i++) {
                    const date = new Date(today);
                    date.setDate(today.getDate() + i);
                    
                    // Schedule for Mondays and Thursdays
                    if (date.getDay() === 1 || date.getDay() === 4) {
                        events.push({
                            title: `Health Check: ${chickenId}`,
                            start: date.toISOString().split('T')[0],
                            className: 'event-health-check',
                            extendedProps: {
                                type: 'check',
                                chickenId: chickenId,
                                description: `Regular health inspection for ${chickenId}`
                            }
                        });
                    }
                }

                // Add Avian Influenza vaccination schedule for each chicken
                const vaccinations = [
                    {
                        title: 'AI H5N1 Primary',
                        days: 7,
                        description: 'First dose of Avian Influenza H5N1 vaccine'
                    },
                    {
                        title: 'AI H9N2',
                        days: 14,
                        description: 'Avian Influenza H9N2 vaccine'
                    },
                    {
                        title: 'AI H5N1 Booster',
                        days: 28,
                        description: 'Booster shot for Avian Influenza H5N1 vaccine'
                    },
                    {
                        title: 'AI Annual Booster',
                        days: 365,
                        description: 'Annual booster for Avian Influenza protection'
                    }
                ];

                vaccinations.forEach(vac => {
                    const date = new Date(today);
                    date.setDate(today.getDate() + vac.days);
                    events.push({
                        title: `${vac.title}: ${chickenId}`,
                        start: date.toISOString().split('T')[0],
                        className: 'event-vaccination',
                        extendedProps: {
                            type: 'vaccination',
                            chickenId: chickenId,
                            description: `${vac.description} for ${chickenId}`
                        }
                    });
                });
            });

        } catch (error) {
            console.error('Error loading events:', error);
        }

        successCallback(events);
    }

    function handleEventClick(info) {
        const event = info.event;
        
        if (event.extendedProps.type === 'analysis') {
            // Show analysis details in modal
            const modal = new DetailsModal();
            modal.show(event.extendedProps.analysis);
        } else {
            // Show regular event details
            showEventDetails(event);
        }
    }

    function handleDateClick(info) {
        const date = info.dateStr;
        showAddEventModal(date);
    }

    function showEventDetails(event) {
        const modalHtml = `
            <div class="modal fade" id="eventModal">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">${event.title}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p><strong>Date:</strong> ${event.start.toLocaleDateString()}</p>
                            <p><strong>Chicken ID:</strong> ${event.extendedProps.chickenId}</p>
                            <p><strong>Type:</strong> ${event.extendedProps.type === 'vaccination' ? 'Vaccination' : 'Health Check'}</p>
                            <p>${event.extendedProps.description}</p>
                            ${event.extendedProps.type === 'vaccination' ? `
                                <div class="alert alert-info mt-3">
                                    <i class="bi bi-info-circle me-2"></i>
                                    Important: Ensure proper vaccine storage and administration procedures.
                                </div>
                            ` : ''}
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Remove existing modal if any
        const existingModal = document.getElementById('eventModal');
        if (existingModal) {
            existingModal.remove();
        }

        // Add and show new modal
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        const modal = new bootstrap.Modal(document.getElementById('eventModal'));
        modal.show();
    }

    function showAddEventModal(date) {
        // Get existing chicken IDs
        const analyses = JSON.parse(localStorage.getItem('analyses') || '[]');
        const chickenIds = [...new Set(analyses.map(a => a.chickenId || ''))].filter(id => id);
        
        // If no chicken IDs found, create default ones
        if (chickenIds.length === 0) {
            for (let i = 1; i <= 5; i++) {
                chickenIds.push(`Chicken ${i}`);
            }
        }

        const modalHtml = `
            <div class="modal fade" id="addEventModal">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Schedule Event</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <form id="addEventForm">
                                <div class="mb-3">
                                    <label class="form-label">Chicken ID</label>
                                    <select class="form-select" id="chickenId" required>
                                        ${chickenIds.map(id => `<option value="${id}">${id}</option>`).join('')}
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Event Type</label>
                                    <select class="form-select" id="eventType">
                                        <option value="health-check">Health Check</option>
                                        <option value="vaccination">Vaccination</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Notes</label>
                                    <textarea class="form-control" id="eventNotes" rows="3"></textarea>
                                </div>
                                <input type="hidden" id="eventDate" value="${date}">
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" onclick="saveEvent()">Schedule</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Remove existing modal if any
        const existingModal = document.getElementById('addEventModal');
        if (existingModal) {
            existingModal.remove();
        }

        // Add and show new modal
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        const modal = new bootstrap.Modal(document.getElementById('addEventModal'));
        modal.show();
    }

    // Add global function for saving events
    window.saveEvent = function() {
        const chickenId = document.getElementById('chickenId').value;
        const type = document.getElementById('eventType').value;
        const notes = document.getElementById('eventNotes').value;
        const date = document.getElementById('eventDate').value;

        const newEvent = {
            title: `${type === 'health-check' ? 'Health Check' : 'Vaccination'}: ${chickenId}`,
            start: date,
            className: `event-${type}`,
            extendedProps: {
                type: type,
                chickenId: chickenId,
                description: notes || `Scheduled ${type} for ${chickenId}`
            }
        };

        calendar.addEvent(newEvent);
        bootstrap.Modal.getInstance(document.getElementById('addEventModal')).hide();
    };

    function getEventClass(status) {
        switch(status.toLowerCase()) {
            case 'healthy': return 'event-healthy';
            case 'at risk': return 'event-warning';
            case 'infected': return 'event-danger';
            default: return 'event-default';
        }
    }
     // Sidebar functionality
     const toggleBtn = document.getElementById('sidebarToggle');
     const sidebar = document.getElementById('sidebar');
     const menuLinks = document.querySelectorAll('.sidebar-menu a');
     const currentPage = window.location.pathname.split('/').pop();

     // Highlight current page in sidebar
     menuLinks.forEach(link => {
         const linkPage = link.getAttribute('href').split('/').pop();
         if (linkPage === currentPage) {
             link.classList.add('active');
         }
     });

     // Sidebar toggle
     if (toggleBtn && sidebar) {
         toggleBtn.addEventListener('click', () => {
             sidebar.classList.toggle('collapsed');
             localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
         });
     }

     // Load saved state
     const savedState = localStorage.getItem('sidebarCollapsed');
     if (savedState === 'true') {
         sidebar.classList.add('collapsed');
     }

     // Prevent sidebar from expanding when clicking menu items
     menuLinks.forEach(link => {
         link.addEventListener('click', (e) => {
             if (sidebar.classList.contains('collapsed')) {
                 e.stopPropagation();
             }
         });
     });

     sidebar.addEventListener('click', function(e) {
         if (sidebar.classList.contains('collapsed') && 
             e.target.closest('.sidebar-menu li a')) {
             e.stopPropagation();
         }
     });
 
     // Profile dropdown functionality
     const profileBtn = document.getElementById('profileBtn');
     const profileDropdown = document.getElementById('profileDropdown');
 
     if (profileBtn && profileDropdown) {
         profileBtn.addEventListener('click', () => {
             profileDropdown.style.display = profileDropdown.style.display === 'flex' ? 'none' : 'flex';
         });
 
         // Close dropdown when clicking outside
         document.addEventListener('click', (e) => {
             if (!profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
                 profileDropdown.style.display = 'none';
             }
         });
     }
});
