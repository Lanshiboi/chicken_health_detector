document.addEventListener('DOMContentLoaded', function() {
    let healthChart = null;
    let distributionChart = null;

    // Initialize dashboard
    initializeDashboard();
    setupEventListeners();

    function initializeDashboard() {
        const analyses = getAnalyses();
        if (analyses && analyses.length > 0) {
            updateStatistics(analyses);
            updateCharts(analyses);
            updateRecentAlerts(analyses);
        } else {
            showEmptyState();
        }
    }

    function getAnalyses() {
        try {
            const data = localStorage.getItem('analyses');
            return data ? JSON.parse(data) : [];
        } catch (error) {
            console.error('Error loading analyses:', error);
            showError('Failed to load analyses data');
            return [];
        }
    }

    function updateStatistics(analyses) {
        // Treatment recommendations based on health status
        const treatmentRecommendations = {
            'healthy': 'No treatment needed.',
            'at risk': 'Consider monitoring closely and providing supplements.',
            'infected': 'Immediate treatment required. Refer to laboratory for analysis.'
        };

        // Calculate statistics
        const stats = { total: 0, healthy: 0, atRisk: 0, infected: 0 };
        analyses.forEach(analysis => {
            stats.total++;
            switch(analysis.status.toLowerCase()) {
                case 'healthy': stats.healthy++; break;
                case 'at risk': stats.atRisk++; break;
                case 'infected': stats.infected++; break;
            }
        });

        // Update counters
        document.getElementById('totalCount').textContent = stats.total;
        document.getElementById('healthyCount').textContent = stats.healthy;
        document.getElementById('atRiskCount').textContent = stats.atRisk;
        document.getElementById('infectedCount').textContent = stats.infected;
        
        // Update progress bars
        if (stats.total > 0) {
            const healthyPercent = (stats.healthy / stats.total) * 100;
            const atRiskPercent = (stats.atRisk / stats.total) * 100;
            const infectedPercent = (stats.infected / stats.total) * 100;

            document.getElementById('healthyProgress').style.width = `${healthyPercent}%`;
            document.getElementById('atRiskProgress').style.width = `${atRiskPercent}%`;
            document.getElementById('infectedProgress').style.width = `${infectedPercent}%`;
        }

        return stats;
    }

    function updateCharts(analyses) {
        updateHealthChart(analyses);
        updateDistributionChart(analyses);
    }

    function updateHealthChart(analyses) {
        const ctx = document.getElementById('healthChart');
        if (!ctx) return;

        // Destroy existing chart if it exists
        if (healthChart) {
            healthChart.destroy();
        }

        // Get last 7 days data
        const last7Days = getLast7DaysData(analyses);

        healthChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: last7Days.labels,
                datasets: [
                    {
                        label: 'Healthy',
                        data: last7Days.healthy,
                        borderColor: '#10B981',
                        backgroundColor: '#10B98120',
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'At Risk',
                        data: last7Days.atRisk,
                        borderColor: '#F59E0B',
                        backgroundColor: '#F59E0B20',
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'Infected',
                        data: last7Days.infected,
                        borderColor: '#EF4444',
                        backgroundColor: '#EF444420',
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        align: 'end'
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }

    function updateDistributionChart(analyses) {
        const ctx = document.getElementById('distributionChart');
        if (!ctx) return;

        // Destroy existing chart if it exists
        if (distributionChart) {
            distributionChart.destroy();
        }

        const stats = analyses.reduce((acc, analysis) => {
            switch(analysis.status.toLowerCase()) {
                case 'healthy': acc.healthy++; break;
                case 'at risk': acc.atRisk++; break;
                case 'infected': acc.infected++; break;
            }
            return acc;
        }, { healthy: 0, atRisk: 0, infected: 0 });

        distributionChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Healthy', 'At Risk', 'Infected'],
                datasets: [{
                    data: [stats.healthy, stats.atRisk, stats.infected],
                    backgroundColor: ['#10B981', '#F59E0B', '#EF4444'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                },
                cutout: '70%'
            }
        });
    }

    function getLast7DaysData(analyses) {
        const days = Array.from({length: 7}, (_, i) => {
            const d = new Date();
            d.setDate(d.getDate() - (6 - i));
            return d.toISOString().split('T')[0];
        });

        const data = {
            labels: days.map(d => new Date(d).toLocaleDateString('en-US', { weekday: 'short' })),
            healthy: Array(7).fill(0),
            atRisk: Array(7).fill(0),
            infected: Array(7).fill(0)
        };

        analyses.forEach(analysis => {
            const date = analysis.date.split('T')[0];
            const dayIndex = days.indexOf(date);
            if (dayIndex !== -1) {
                switch(analysis.status.toLowerCase()) {
                    case 'healthy': data.healthy[dayIndex]++; break;
                    case 'at risk': data.atRisk[dayIndex]++; break;
                    case 'infected': data.infected[dayIndex]++; break;
                }
            }
        });

        return data;
    }

    function updateRecentAlerts(analyses) {
        const alertsTable = document.getElementById('alertsTable');
        if (!alertsTable) return;

        // Get non-healthy analyses
        const alerts = analyses
            .filter(a => a.status.toLowerCase() !== 'healthy')
            .sort((a, b) => new Date(b.date) - new Date(a.date))
            .slice(0, 3);

        if (alerts.length === 0) {
            alertsTable.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center py-4">
                        <i class="bi bi-check-circle-fill text-success fs-4 d-block mb-2"></i>
                        <p class="mb-0">No alerts at this time</p>
                    </td>
                </tr>
            `;
            return;
        }

        alertsTable.innerHTML = alerts.map(alert => `
            <tr>
                <td>${treatmentRecommendations[alert.status.toLowerCase()] || 'No recommendation'}</td>
                <td>${new Date(alert.date).toLocaleDateString()}</td>
                <td>${alert.chickenId || 'Unknown'}</td>
                <td>
                    <span class="status-badge ${getStatusClass(alert.status)}">
                        ${alert.status}
                    </span>
                </td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="showDetails('${alert.id || ''}')">
                        View Details
                    </button>
                </td>
            </tr>
        `).join('');
    }

    function showEmptyState() {
        // Update counters to 0
        ['totalCount', 'healthyCount', 'atRiskCount', 'infectedCount'].forEach(id => {
            document.getElementById(id).textContent = '0';
        });

        // Reset progress bars
        ['healthyProgress', 'atRiskProgress', 'infectedProgress'].forEach(id => {
            document.getElementById(id).style.width = '0%';
        });

        // Show empty state in alerts table with guidance
        const alertsTable = document.getElementById('alertsTable');
        if (alertsTable) {
            alertsTable.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center py-4">
                        <i class="bi bi-inbox fs-4 d-block mb-2 text-muted"></i>
                        <p class="mb-0">No data available</p>
                        <p class="text-muted">Start by analyzing some chickens</p>
                        <p class="text-muted">Please ensure that you have added analyses to see the data here.</p>
                    </td>
                </tr>
            `;
        }

        // Initialize empty charts
        updateCharts([]);
    }

    function setupEventListeners() {
        // Listen for analysis updates
        document.addEventListener('analysisUpdated', function() {
            initializeDashboard();
        });

        // Add global function for showing details
        window.showDetails = function(id) {
            const analyses = getAnalyses();
            const analysis = analyses.find(a => a.id === id);
            if (analysis) {
                const modal = new DetailsModal();
                modal.show(analysis);
            }
        };

        // Initialize sidebar and profile dropdown
        initSidebar();
        initProfileDropdown();
    }

    function getStatusClass(status) {
        switch(status.toLowerCase()) {
            case 'healthy': return 'status-healthy';
            case 'at risk': return 'status-warning';
            case 'infected': return 'status-critical';
            default: return 'status-secondary';
        }
    }
     // Sidebar functionality
     const toggleBtn = document.getElementById('sidebarToggle');
     const sidebar = document.getElementById('sidebar');
     const menuLinks = document.querySelectorAll('.sidebar-menu a');
     const currentPage = window.location.pathname.split('/').pop();
 
     // Highlight current page in sidebar
     menuLinks.forEach(link => {
         const linkPage = link.getAttribute('href').split('/').pop();
         if (linkPage === currentPage) {
             link.classList.add('active');
         }
     });
 
     // Sidebar toggle
     if (toggleBtn && sidebar) {
         toggleBtn.addEventListener('click', () => {
             sidebar.classList.toggle('collapsed');
             localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
             
             // Ensure active link remains visible when collapsed
             const activeLink = document.querySelector('.sidebar-menu a.active');
             if (activeLink && sidebar.classList.contains('collapsed')) {
                 activeLink.querySelector('span').style.display = 'block';
             }
         });
     }
 
     // Load saved state
     const savedState = localStorage.getItem('sidebarCollapsed');
     if (savedState === 'true') {
         sidebar.classList.add('collapsed');
     }
 
     // Prevent sidebar from expanding when clicking menu items
     menuLinks.forEach(link => {
         link.addEventListener('click', (e) => {
             if (sidebar.classList.contains('collapsed')) {
                 e.stopPropagation();
             }
         });
     });
 
     sidebar.addEventListener('click', function(e) {
         if (sidebar.classList.contains('collapsed') && 
             e.target.closest('.sidebar-menu li a')) {
             e.stopPropagation();
         }
     });
 
     // Profile dropdown functionality
     const profileBtn = document.getElementById('profileBtn');
     const profileDropdown = document.getElementById('profileDropdown');
 
     if (profileBtn && profileDropdown) {
         profileBtn.addEventListener('click', () => {
             profileDropdown.style.display = profileDropdown.style.display === 'flex' ? 'none' : 'flex';
         });
 
         // Close dropdown when clicking outside
         document.addEventListener('click', (e) => {
             if (!profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
                 profileDropdown.style.display = 'none';
             }
         });
     }
    
   
   });
 
 