class DetailsModal {
    constructor() {
        this.createModal();
        this.setupEventListeners();
    }

    createModal() {
        // Create modal HTML if it doesn't exist
        if (!document.getElementById('detailsModal')) {
            const modalHTML = `
                <div class="modal fade" id="detailsModal" tabindex="-1">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Analysis Details</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <div class="text-center mb-4">
                                    <img id="modalImage" src="" alt="Analysis" class="img-fluid rounded" style="max-height: 300px;">
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="fw-bold">Date & Time:</label>
                                            <p id="modalDate" class="mb-1"></p>
                                        </div>
                                        <div class="mb-3">
                                            <label class="fw-bold">Location:</label>
                                            <p id="modalLocation" class="mb-1"></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="fw-bold">Status:</label>
                                            <div id="modalStatus"></div>
                                        </div>
                                        <div class="mb-3">
                                            <label class="fw-bold">Health Score:</label>
                                            <div class="progress">
                                                <div id="modalHealthScore" class="progress-bar" role="progressbar"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-4">
                                    <h6 class="fw-bold">Detailed Results:</h6>
                                    <ul id="modalDetails" class="list-unstyled"></ul>
                                </div>
                                <div class="mb-3">
                                    <label class="fw-bold">Notes:</label>
                                    <textarea id="modalNotes" class="form-control" rows="3"></textarea>
                                </div>
                                <div id="modalCharts" class="row mt-4">
                                    <div class="col-md-6">
                                        <canvas id="modalTrendChart"></canvas>
                                    </div>
                                    <div class="col-md-6">
                                        <canvas id="modalIndicatorsChart"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary" id="modalSave">Save Changes</button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', modalHTML);
        }

        this.modal = new bootstrap.Modal(document.getElementById('detailsModal'));
        this.modalElement = document.getElementById('detailsModal');
    }

    setupEventListeners() {
        const saveBtn = document.getElementById('modalSave');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => this.saveChanges());
        }

        // Listen for modal close to cleanup charts
        this.modalElement.addEventListener('hidden.bs.modal', () => {
            this.destroyCharts();
        });
    }

    show(data) {
        console.log('Data passed to modal:', data); // Debugging line to check data
        this.currentData = data;

        this.updateModalContent(data);
        this.modal.show();
    }

    updateModalContent(data) {
        // Treatment recommendations based on health status
        const treatmentRecommendations = {
            'healthy': 'No treatment needed.',
            'at risk': 'Consider monitoring closely and providing supplements.',
            'infected': 'Immediate treatment required. Refer to laboratory for analysis.'
        };

        document.getElementById('modalImage').src = data.image;
        document.getElementById('modalDate').textContent = data.date;
        document.getElementById('modalLocation').textContent = data.location || 'Not specified';

        // Update status with badge
        const statusBadge = this.createStatusBadge(data.status);
        document.getElementById('modalStatus').innerHTML = statusBadge;

        // Update health score and treatment recommendation
        const recommendation = treatmentRecommendations[data.status.toLowerCase()] || 'No recommendation available.';

        const healthScore = this.getHealthScore(data.status);
        const healthScoreBar = document.getElementById('modalHealthScore');
        healthScoreBar.style.width = `${healthScore}%`;
        healthScoreBar.className = `progress-bar ${this.getHealthScoreClass(healthScore)}`;
        healthScoreBar.textContent = `${healthScore}%`;

        // Update details and recommendation
        const detailsList = document.getElementById('modalDetails');
        detailsList.innerHTML = data.details.map(detail => `
            <li class="mb-2">
                <i class="bi bi-check-circle-fill text-success me-2"></i>
                ${detail}
            </li>
        `).join('');
        detailsList.innerHTML += `<li class="mb-2"><strong>Treatment Recommendation:</strong> ${recommendation}</li>`;

        // Update notes
        document.getElementById('modalNotes').value = data.notes || '';

        // Update charts
        this.updateCharts(data);
    }

    updateCharts(data) {
        this.destroyCharts();

        // Create trend chart
        const trendCtx = document.getElementById('modalTrendChart');
        this.trendChart = new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5'],
                datasets: [{
                    label: 'Health Trend',
                    data: this.generateTrendData(data.status),
                    borderColor: this.getStatusColor(data.status),
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Health Trend'
                    }
                }
            }
        });

        // Create indicators chart
        const indicatorsCtx = document.getElementById('modalIndicatorsChart');
        this.indicatorsChart = new Chart(indicatorsCtx, {
            type: 'radar',
            data: {
                labels: ['Activity', 'Appetite', 'Posture', 'Feathers', 'Movement'],
                datasets: [{
                    label: 'Health Indicators',
                    data: this.generateIndicatorData(data.status),
                    backgroundColor: `${this.getStatusColor(data.status)}40`,
                    borderColor: this.getStatusColor(data.status)
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Health Indicators'
                    }
                },
                scales: {
                    r: {
                        min: 0,
                        max: 100
                    }
                }
            }
        });
    }

    destroyCharts() {
        if (this.trendChart) {
            this.trendChart.destroy();
        }
        if (this.indicatorsChart) {
            this.indicatorsChart.destroy();
        }
    }

    saveChanges() {
        const notes = document.getElementById('modalNotes').value;
        
        // Update current data
        this.currentData.notes = notes;
        this.currentData.lastModified = new Date().toISOString();

        // Update in localStorage
        const analyses = JSON.parse(localStorage.getItem('analyses') || '[]');
        const index = analyses.findIndex(a => a.date === this.currentData.date);
        if (index !== -1) {
            analyses[index] = this.currentData;
            localStorage.setItem('analyses', JSON.stringify(analyses));
        }

        // Trigger update event
        document.dispatchEvent(new CustomEvent('analysisUpdated', {
            detail: this.currentData
        }));

        // Close modal
        this.modal.hide();
    }

    createStatusBadge(status) {
        const className = this.getStatusClass(status);
        return `<span class="badge ${className}">${status}</span>`;
    }

    getStatusClass(status) {
        switch(status.toLowerCase()) {
            case 'healthy': return 'bg-success';
            case 'at risk': return 'bg-warning';
            case 'infected': return 'bg-danger';
            default: return 'bg-secondary';
        }
    }

    getStatusColor(status) {
        switch(status.toLowerCase()) {
            case 'healthy': return '#10B981';
            case 'at risk': return '#F59E0B';
            case 'infected': return '#EF4444';
            default: return '#6B7280';
        }
    }

    getHealthScore(status) {
        switch(status.toLowerCase()) {
            case 'healthy': return 90;
            case 'at risk': return 60;
            case 'infected': return 30;
            default: return 50;
        }
    }

    getHealthScoreClass(score) {
        if (score >= 80) return 'bg-success';
        if (score >= 50) return 'bg-warning';
        return 'bg-danger';
    }

    generateTrendData(status) {
        const baseScore = this.getHealthScore(status);
        return Array(5).fill(0).map(() => 
            baseScore + (Math.random() * 10 - 5)
        );
    }

    generateIndicatorData(status) {
        const baseScore = this.getHealthScore(status);
        return Array(5).fill(0).map(() => 
            Math.max(0, Math.min(100, baseScore + (Math.random() * 20 - 10)))
        );
    }
}

// Initialize for global use
window.DetailsModal = DetailsModal;

// Global view details function
function viewDetails(analysisId) {
    const analyses = JSON.parse(localStorage.getItem('analyses') || '[]');
    const analysis = analyses.find(a => a.id === analysisId);
    
    if (!analysis) {
        alert('Analysis not found');
        return;
    }

    // Initialize modal if not already initialized
    if (!window.detailsModalInstance) {
        window.detailsModalInstance = new DetailsModal();
    }

    // Show the modal with the analysis data
    window.detailsModalInstance.show(analysis);
}
