document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const reportsTable = document.getElementById('reportsTable');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const totalCount = document.getElementById('totalCount');
    const healthyCount = document.getElementById('healthyCount');
    const atRiskCount = document.getElementById('atRiskCount');
    const infectedCount = document.getElementById('infectedCount');
    const distributionChartEl = document.getElementById('distributionChart');
    const weeklyChartEl = document.getElementById('weeklyChart');
    const filterSelect = document.getElementById('filterSelect');

    function getAnalyses() {
        try {
            const data = localStorage.getItem('analyses');
            return data ? JSON.parse(data) : [];
        } catch (error) {
            console.error('Error loading analyses:', error);
            return [];
        }
    }

    function updateCounts(analyses) {
        if (!totalCount || !healthyCount || !atRiskCount || !infectedCount) return;
        
        totalCount.textContent = analyses.length;
        healthyCount.textContent = analyses.filter(a => a.status.toLowerCase() === 'healthy').length;
        atRiskCount.textContent = analyses.filter(a => a.status.toLowerCase() === 'at risk').length;
        infectedCount.textContent = analyses.filter(a => a.status.toLowerCase() === 'infected').length;
    }

    function updateReportTable(analyses) {
        if (!reportsTable) return;

        // Treatment recommendations based on health status
        const treatmentRecommendations = {
            'healthy': 'No treatment needed.',
            'at risk': 'Consider monitoring closely and providing supplements.',
            'infected': 'Immediate treatment required. Refer to laboratory for analysis.'
        };

        reportsTable.innerHTML = analyses.map(analysis => `
            <tr>
                <td><img src="${analysis.image}" alt="Chicken Image" class="analysis-image"></td>
                <td>
                    <div>Chicken ID: ${analysis.chickenId || 'Unknown'}</div>
                    <div>Date: ${new Date(analysis.date).toLocaleString()}</div>
                </td>
                <td>
                    <span class="status-badge ${analysis.status.toLowerCase()}">
                        ${analysis.status}
                    </span>
                </td>
                <td>${treatmentRecommendations[analysis.status.toLowerCase()] || 'No recommendation'}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="viewDetails('${analysis.id}')">
                        <i class="fas fa-eye"></i> View
                    </button>
                </td>
            </tr>
        `).join('');
    }

    function initializeCharts(analyses) {
        if (!distributionChartEl || !weeklyChartEl) return;

        // Status distribution chart
        const statusCounts = {
            healthy: analyses.filter(a => a.status.toLowerCase() === 'healthy').length,
            atRisk: analyses.filter(a => a.status.toLowerCase() === 'at risk').length,
            infected: analyses.filter(a => a.status.toLowerCase() === 'infected').length
        };

        new Chart(distributionChartEl, {
            type: 'doughnut',
            data: {
                labels: ['Healthy', 'At Risk', 'Infected'],
                datasets: [{
                    data: [statusCounts.healthy, statusCounts.atRisk, statusCounts.infected],
                    backgroundColor: [
                        '#10B981',
                        '#F59E0B',
                        '#EF4444'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });

        // Weekly analysis chart
        const weeklyData = getWeeklyData(analyses);
        new Chart(weeklyChartEl, {
            type: 'line',
            data: {
                labels: weeklyData.labels,
                datasets: [
                    {
                        label: 'Healthy',
                        data: weeklyData.healthy,
                        borderColor: '#10B981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        tension: 0.3
                    },
                    {
                        label: 'At Risk',
                        data: weeklyData.atRisk,
                        borderColor: '#F59E0B',
                        backgroundColor: 'rgba(245, 158, 11, 0.1)',
                        tension: 0.3
                    },
                    {
                        label: 'Infected',
                        data: weeklyData.infected,
                        borderColor: '#EF4444',
                        backgroundColor: 'rgba(239, 68, 68, 0.1)',
                        tension: 0.3
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    function getWeeklyData(analyses) {
        const result = {
            labels: [],
            healthy: [],
            atRisk: [],
            infected: []
        };

        // Group by week (simplified example)
        // In real implementation, you'd group by actual weeks
        const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        result.labels = days;
        
        // Sample data - replace with actual weekly grouping logic
        days.forEach(day => {
            result.healthy.push(Math.floor(Math.random() * 10));
            result.atRisk.push(Math.floor(Math.random() * 5));
            result.infected.push(Math.floor(Math.random() * 3));
        });

        return result;
    }

    function initializeReports() {
        try {
            // Show loading spinner
            if (loadingSpinner) loadingSpinner.style.display = 'flex';
            
            // Set timeout fallback (5 seconds)
            const timeoutId = setTimeout(() => {
                if (loadingSpinner) loadingSpinner.style.display = 'none';
                console.error('Loading timeout exceeded');
            }, 5000);

            // Load and process data
            const analyses = getAnalyses();
            updateCounts(analyses);
            updateReportTable(analyses);
            initializeCharts(analyses);
            
            // Hide spinner when done
            clearTimeout(timeoutId);
            if (loadingSpinner) loadingSpinner.style.display = 'none';
        } catch (error) {
            console.error('Error initializing reports:', error);
            if (loadingSpinner) loadingSpinner.style.display = 'none';
        }
    }

    // Initialize reports when page loads
    initializeReports();

    // Listen for new analysis events from analyze page
    document.addEventListener('analysisUpdated', initializeReports);

    // Sidebar functionality
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    const menuLinks = document.querySelectorAll('.sidebar-menu a');
    const currentPage = window.location.pathname.split('/').pop();

    // Highlight current page in sidebar
    menuLinks.forEach(link => {
        const linkPage = link.getAttribute('href').split('/').pop();
        if (linkPage === currentPage) {
            link.classList.add('active');
        }
    });

    // Sidebar toggle
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
            
            // Ensure active link remains visible when collapsed
            const activeLink = document.querySelector('.sidebar-menu a.active');
            if (activeLink && sidebar.classList.contains('collapsed')) {
                activeLink.querySelector('span').style.display = 'block';
            }
        });
    }

    // Load saved state
    const savedState = localStorage.getItem('sidebarCollapsed');
    if (savedState === 'true') {
        sidebar.classList.add('collapsed');
    }

    // Prevent sidebar from expanding when clicking menu items
    menuLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            if (sidebar.classList.contains('collapsed')) {
                e.stopPropagation();
            }
        });
    });

    sidebar.addEventListener('click', function(e) {
        if (sidebar.classList.contains('collapsed') && 
            e.target.closest('.sidebar-menu li a')) {
            e.stopPropagation();
        }
    });

    // Profile dropdown functionality
    const profileBtn = document.getElementById('profileBtn');
    const profileDropdown = document.getElementById('profileDropdown');

    if (profileBtn && profileDropdown) {
        profileBtn.addEventListener('click', () => {
            profileDropdown.style.display = profileDropdown.style.display === 'flex' ? 'none' : 'flex';
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
                profileDropdown.style.display = 'none';
            }
        });
    }
   
  
        filterSelect.addEventListener('change', () => {
        const selectedStatus = filterSelect.value.toLowerCase();
        const rows = document.querySelectorAll('#reportsTable tr');
    
        rows.forEach(row => {
            const statusCell = row.querySelector('td:nth-child(3)');
            if (!statusCell) return;
    
            const statusText = statusCell.textContent.trim().toLowerCase();
    
            if (selectedStatus === 'all' || statusText === selectedStatus) {
            row.style.display = '';  // Show the row
            } else {
            row.style.display = 'none';  // Hide the row
            }
        });
        });
  });

