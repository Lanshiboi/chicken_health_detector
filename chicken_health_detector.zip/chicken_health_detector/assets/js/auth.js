class Auth {
    constructor() {
        // Initialize forms
        this.loginForm = document.getElementById('loginForm');
        this.registerForm = document.getElementById('registerForm');
        
        // Login form elements
        this.loginEmail = document.getElementById('loginEmail');
        this.loginPassword = document.getElementById('loginPassword');
        this.loginEmailError = document.getElementById('loginEmailError');
        this.loginPasswordError = document.getElementById('loginPasswordError');
        this.loginTogglePassword = document.getElementById('loginTogglePassword');
        this.rememberCheckbox = document.getElementById('remember');

        // Register form elements
        this.firstName = document.getElementById('firstName');
        this.lastName = document.getElementById('lastName');
        this.registerEmail = document.getElementById('registerEmail');
        this.registerPassword = document.getElementById('registerPassword');
        this.confirmPassword = document.getElementById('confirmPassword');
        this.firstNameError = document.getElementById('firstNameError');
        this.lastNameError = document.getElementById('lastNameError');
        this.registerEmailError = document.getElementById('registerEmailError');
        this.registerPasswordError = document.getElementById('registerPasswordError');
        this.confirmPasswordError = document.getElementById('confirmPasswordError');
        this.registerTogglePassword = document.getElementById('registerTogglePassword');
        this.confirmTogglePassword = document.getElementById('confirmTogglePassword');

        // Social login buttons
        this.socialButtons = {
            google: document.querySelectorAll('.btn-google'),
            github: document.querySelectorAll('.btn-github'),
            facebook: document.querySelectorAll('.btn-facebook')
        };

        this.init();
    }

    init() {
        // Form submissions
        this.loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        this.registerForm.addEventListener('submit', (e) => this.handleRegister(e));

        // Password toggles
        this.loginTogglePassword.addEventListener('click', () => 
            this.togglePasswordVisibility(this.loginPassword, this.loginTogglePassword));
        this.registerTogglePassword.addEventListener('click', () => 
            this.togglePasswordVisibility(this.registerPassword, this.registerTogglePassword));
        this.confirmTogglePassword.addEventListener('click', () => 
            this.togglePasswordVisibility(this.confirmPassword, this.confirmTogglePassword));

        // Real-time validation
        this.loginEmail.addEventListener('input', () => this.validateEmail(this.loginEmail, this.loginEmailError));
        this.loginPassword.addEventListener('input', () => this.validatePassword(this.loginPassword, this.loginPasswordError));

        this.firstName.addEventListener('input', () => this.validateName(this.firstName, this.firstNameError, 'First name'));
        this.lastName.addEventListener('input', () => this.validateName(this.lastName, this.lastNameError, 'Last name'));
        this.registerEmail.addEventListener('input', () => this.validateEmail(this.registerEmail, this.registerEmailError));
        this.registerPassword.addEventListener('input', () => this.validatePassword(this.registerPassword, this.registerPasswordError));
        this.confirmPassword.addEventListener('input', () => this.validateConfirmPassword());

        // Social login handlers
        Object.entries(this.socialButtons).forEach(([provider, buttons]) => {
            buttons.forEach(button => {
                button.addEventListener('click', () => this.handleSocialLogin(provider));
            });
        });

        // Check for existing session
        this.checkSession();
    }

    async handleLogin(e) {
        e.preventDefault();
        console.log('Login attempt...');

        if (!this.validateLoginForm()) return;

        this.setLoadingState(this.loginForm, true);

        try {
            const response = await fetch('includes/auth.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'login',
                    email: this.loginEmail.value,
                    password: this.loginPassword.value,
                    remember: this.rememberCheckbox.checked
                })
            });

            const data = await response.json();

            if (data.success) {
                localStorage.setItem('user', JSON.stringify(data.user));
                localStorage.setItem('authToken', data.token);
                window.location.href = 'dashboard.html';
            } else {
                this.showError(this.loginPasswordError, data.error || 'Login failed');
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showError(this.loginPasswordError, 'Login failed. Please try again.');
        } finally {
            this.setLoadingState(this.loginForm, false);
        }
    }

    async handleRegister(e) {
        e.preventDefault();
        console.log('Registration attempt...');

        if (!this.validateRegisterForm()) return;

        this.setLoadingState(this.registerForm, true);

        try {
            const response = await fetch('includes/auth.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'register',
                    firstName: this.firstName.value,
                    lastName: this.lastName.value,
                    email: this.registerEmail.value,
                    password: this.registerPassword.value
                })
            });

            const data = await response.json();

            if (data.success) {
                localStorage.setItem('user', JSON.stringify(data.user));
                localStorage.setItem('authToken', data.token);
                window.location.href = 'dashboard.html';
            } else {
                this.showError(this.registerEmailError, data.error || 'Registration failed');
            }
        } catch (error) {
            console.error('Registration error:', error);
            this.showError(this.registerEmailError, 'Registration failed. Please try again.');
        } finally {
            this.setLoadingState(this.registerForm, false);
        }
    }

    validateLoginForm() {
        let isValid = true;

        if (!this.validateEmail(this.loginEmail, this.loginEmailError)) isValid = false;
        if (!this.validatePassword(this.loginPassword, this.loginPasswordError)) isValid = false;

        return isValid;
    }

    validateRegisterForm() {
        let isValid = true;

        if (!this.validateName(this.firstName, this.firstNameError, 'First name')) isValid = false;
        if (!this.validateName(this.lastName, this.lastNameError, 'Last name')) isValid = false;
        if (!this.validateEmail(this.registerEmail, this.registerEmailError)) isValid = false;
        if (!this.validatePassword(this.registerPassword, this.registerPasswordError)) isValid = false;
        if (!this.validateConfirmPassword()) isValid = false;

        return isValid;
    }

    validateName(input, errorElement, fieldName) {
        const value = input.value.trim();
        
        if (!value) {
            this.showError(errorElement, `${fieldName} is required`);
            return false;
        }

        if (value.length < 2) {
            this.showError(errorElement, `${fieldName} must be at least 2 characters`);
            return false;
        }

        if (!/^[a-zA-Z\s]+$/.test(value)) {
            this.showError(errorElement, `${fieldName} can only contain letters`);
            return false;
        }

        this.hideError(errorElement);
        return true;
    }

    validateEmail(input, errorElement) {
        const email = input.value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!email) {
            this.showError(errorElement, 'Email is required');
            return false;
        }

        if (!emailRegex.test(email)) {
            this.showError(errorElement, 'Please enter a valid email');
            return false;
        }

        this.hideError(errorElement);
        return true;
    }

    validatePassword(input, errorElement) {
        const password = input.value;

        if (!password) {
            this.showError(errorElement, 'Password is required');
            return false;
        }

        if (password.length < 8) {
            this.showError(errorElement, 'Password must be at least 8 characters');
            return false;
        }

        if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(password)) {
            this.showError(errorElement, 'Password must contain uppercase, lowercase and numbers');
            return false;
        }

        this.hideError(errorElement);
        return true;
    }

    validateConfirmPassword() {
        if (!this.confirmPassword.value) {
            this.showError(this.confirmPasswordError, 'Please confirm your password');
            return false;
        }

        if (this.confirmPassword.value !== this.registerPassword.value) {
            this.showError(this.confirmPasswordError, 'Passwords do not match');
            return false;
        }

        this.hideError(this.confirmPasswordError);
        return true;
    }

    togglePasswordVisibility(input, icon) {
        const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
        input.setAttribute('type', type);
        icon.classList.toggle('bi-eye');
        icon.classList.toggle('bi-eye-slash');
    }

    showError(element, message) {
        element.textContent = message;
        element.style.display = 'block';
        element.parentElement.classList.add('shake');
        setTimeout(() => {
            element.parentElement.classList.remove('shake');
        }, 500);
    }

    hideError(element) {
        element.style.display = 'none';
    }

    setLoadingState(form, isLoading) {
        const button = form.querySelector('button[type="submit"]');
        button.disabled = isLoading;
        
        if (form.id === 'loginForm') {
            button.innerHTML = isLoading ? 
                '<span class="spinner-border spinner-border-sm me-2"></span>Logging in...' :
                '<i class="bi bi-box-arrow-in-right me-2"></i>Login';
        } else {
            button.innerHTML = isLoading ? 
                '<span class="spinner-border spinner-border-sm me-2"></span>Creating account...' :
                'Create Account';
        }
    }

    async handleSocialLogin(provider) {
        console.log(`${provider} login clicked`);
        try {
            const userData = await this.initSocialLogin(provider);
            if (userData) {
                await this.handleSocialLoginSuccess(provider, userData);
            }
        } catch (error) {
            console.error(`${provider} login error:`, error);
            this.showError(
                this.loginEmailError, 
                `${provider.charAt(0).toUpperCase() + provider.slice(1)} login failed`
            );
        }
    }

    async handleSocialLoginSuccess(provider, userData) {
        try {
            const response = await fetch('includes/auth.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'social_login',
                    provider: provider,
                    userData: JSON.stringify(userData)
                })
            });

            const data = await response.json();

            if (data.success) {
                localStorage.setItem('user', JSON.stringify(data.user));
                localStorage.setItem('authToken', data.token);
                window.location.href = 'dashboard.html';
            } else {
                this.showError(this.loginEmailError, data.error || 'Social login failed');
            }
        } catch (error) {
            console.error('Social login error:', error);
            this.showError(this.loginEmailError, 'Social login failed');
        }
    }

    async initSocialLogin(provider) {
        switch (provider) {
            case 'google':
                return this.initGoogleLogin();
            case 'github':
                return this.initGithubLogin();
            case 'facebook':
                return this.initFacebookLogin();
            default:
                throw new Error('Invalid provider');
        }
    }

    checkSession() {
        const token = localStorage.getItem('authToken');
        const user = localStorage.getItem('user');

        if (token && user) {
            window.location.href = 'dashboard.html';
        }
    }

    static logout() {
        localStorage.removeItem('user');
        localStorage.removeItem('authToken');
        window.location.href = 'auth.html';
    }
}

// Initialize Auth when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing Auth...');
    window.auth = new Auth();
});

// Make logout function globally available
window.logout = () => Auth.logout();
