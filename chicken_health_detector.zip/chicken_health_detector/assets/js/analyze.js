document.addEventListener('DOMContentLoaded', function() {
    // Sidebar functionality
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    const menuLinks = document.querySelectorAll('.sidebar-menu a');
    const currentPage = window.location.pathname.split('/').pop();

    // Highlight current page in sidebar
    menuLinks.forEach(link => {
        const linkPage = link.getAttribute('href').split('/').pop();
        if (linkPage === currentPage) {
            link.classList.add('active');
        }
    });

    // Sidebar toggle
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
            
            // Ensure active link remains visible when collapsed
            const activeLink = document.querySelector('.sidebar-menu a.active');
            if (activeLink && sidebar.classList.contains('collapsed')) {
                activeLink.querySelector('span').style.display = 'block';
            }
        });
    }

    // Load saved state
    const savedState = localStorage.getItem('sidebarCollapsed');
    if (savedState === 'true') {
        sidebar.classList.add('collapsed');
    }

    // Prevent sidebar from expanding when clicking menu items
    menuLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            if (sidebar.classList.contains('collapsed')) {
                e.stopPropagation();
            }
        });
    });

    sidebar.addEventListener('click', function(e) {
        if (sidebar.classList.contains('collapsed') && 
            e.target.closest('.sidebar-menu li a')) {
            e.stopPropagation();
        }
    });

    // Profile dropdown functionality
    const profileBtn = document.getElementById('profileBtn');
    const profileDropdown = document.getElementById('profileDropdown');

    if (profileBtn && profileDropdown) {
        profileBtn.addEventListener('click', () => {
            profileDropdown.style.display = profileDropdown.style.display === 'flex' ? 'none' : 'flex';
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
                profileDropdown.style.display = 'none';
            }
        });
    }

    // Analysis form functionality
    const analysisForm = document.getElementById('analysisForm');
    const imagePreview = document.getElementById('imagePreview');
    const fileInput = document.getElementById('imageUpload');

    if (fileInput) {
        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        });
    }

    if (analysisForm) {
        analysisForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            
            // Add analysis to localStorage
            const analyses = JSON.parse(localStorage.getItem('analyses') || '[]');
            const newAnalysis = {
                id: Date.now(),
                date: new Date().toISOString(),
                chickenId: formData.get('chickenId'),
                status: formData.get('healthStatus'),
                details: formData.get('analysisDetails'),
                image: imagePreview.src
            };
            analyses.push(newAnalysis);
            localStorage.setItem('analyses', JSON.stringify(analyses));
            
            // Trigger analysis update event
            document.dispatchEvent(new CustomEvent('analysisUpdated'));
            
            // Reset form
            this.reset();
            imagePreview.style.display = 'none';
            
            // Show success message
            alert('Analysis submitted successfully!');
        });
    }
});
