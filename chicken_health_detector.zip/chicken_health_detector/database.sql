-- Create the database
CREATE DATABASE IF NOT EXISTS bchi_db;
USE bchi_db;

-- Users table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Farms table
CREATE TABLE farms (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    farm_name VARCHAR(100) NOT NULL,
    location VARCHAR(255),
    capacity INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Chicken batches table
CREATE TABLE chicken_batches (
    id INT PRIMARY KEY AUTO_INCREMENT,
    farm_id INT NOT NULL,
    batch_number VARCHAR(50) NOT NULL,
    breed VARCHAR(100),
    quantity INT NOT NULL,
    arrival_date DATE NOT NULL,
    status ENUM('active', 'completed', 'terminated') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (farm_id) REFERENCES farms(id)
);

-- Individual chickens table
CREATE TABLE chickens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    batch_id INT NOT NULL,
    chicken_id VARCHAR(50) UNIQUE NOT NULL,
    status ENUM('healthy', 'sick', 'deceased') DEFAULT 'healthy',
    current_weight DECIMAL(5,2),
    age_days INT,
    last_checked TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (batch_id) REFERENCES chicken_batches(id)
);

-- Health analysis table
CREATE TABLE health_analysis (
    id INT PRIMARY KEY AUTO_INCREMENT,
    chicken_id INT NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    analysis_result TEXT,
    confidence_score DECIMAL(5,2),
    diagnosis VARCHAR(255),
    recommendations TEXT,
    analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (chicken_id) REFERENCES chickens(id)
);

-- Analysis history table
CREATE TABLE analysis_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    chicken_id INT NOT NULL,
    analysis_type ENUM('image', 'weight', 'behavior') NOT NULL,
    previous_status VARCHAR(50),
    current_status VARCHAR(50),
    change_percentage DECIMAL(5,2),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (chicken_id) REFERENCES chickens(id)
);

-- Daily records table
CREATE TABLE daily_records (
    id INT PRIMARY KEY AUTO_INCREMENT,
    batch_id INT NOT NULL,
    date DATE NOT NULL,
    total_feed_consumed DECIMAL(10,2),
    average_weight DECIMAL(5,2),
    mortality_count INT DEFAULT 0,
    temperature DECIMAL(4,2),
    humidity DECIMAL(4,2),
    notes TEXT,
    recorded_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (batch_id) REFERENCES chicken_batches(id),
    FOREIGN KEY (recorded_by) REFERENCES users(id)
);

-- Feed inventory table
CREATE TABLE feed_inventory (
    id INT PRIMARY KEY AUTO_INCREMENT,
    farm_id INT NOT NULL,
    feed_type VARCHAR(100) NOT NULL,
    quantity_kg DECIMAL(10,2) NOT NULL,
    unit_price DECIMAL(10,2),
    purchase_date DATE,
    expiry_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (farm_id) REFERENCES farms(id)
);

-- Medication inventory table
CREATE TABLE medication_inventory (
    id INT PRIMARY KEY AUTO_INCREMENT,
    farm_id INT NOT NULL,
    medication_name VARCHAR(100) NOT NULL,
    quantity INT NOT NULL,
    unit VARCHAR(50),
    expiry_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (farm_id) REFERENCES farms(id)
);

-- Treatment records table
CREATE TABLE treatment_records (
    id INT PRIMARY KEY AUTO_INCREMENT,
    chicken_id INT NOT NULL,
    medication_id INT NOT NULL,
    dosage VARCHAR(50),
    treatment_date DATE,
    next_treatment_date DATE,
    notes TEXT,
    administered_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (chicken_id) REFERENCES chickens(id),
    FOREIGN KEY (medication_id) REFERENCES medication_inventory(id),
    FOREIGN KEY (administered_by) REFERENCES users(id)
);

-- Vaccination schedule table
CREATE TABLE vaccination_schedule (
    id INT PRIMARY KEY AUTO_INCREMENT,
    batch_id INT NOT NULL,
    vaccine_name VARCHAR(100) NOT NULL,
    schedule_date DATE NOT NULL,
    status ENUM('pending', 'completed', 'missed') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (batch_id) REFERENCES chicken_batches(id)
);

-- Alert settings table
CREATE TABLE alert_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    alert_type VARCHAR(50) NOT NULL,
    threshold_value DECIMAL(10,2),
    is_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Notifications table
CREATE TABLE notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50),
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Create stored procedure for automatic chicken ID generation
DELIMITER //

CREATE PROCEDURE generate_chicken_id(
    IN p_batch_id INT,
    OUT p_chicken_id VARCHAR(50)
)
BEGIN
    DECLARE v_farm_id INT;
    DECLARE v_batch_number VARCHAR(50);
    DECLARE v_count INT;
    
    -- Get farm_id and batch_number
    SELECT f.id, cb.batch_number, COUNT(c.id) + 1
    INTO v_farm_id, v_batch_number, v_count
    FROM chicken_batches cb
    JOIN farms f ON cb.farm_id = f.id
    LEFT JOIN chickens c ON cb.id = c.batch_id
    WHERE cb.id = p_batch_id
    GROUP BY cb.id;
    
    -- Generate chicken ID: FARM-BATCH-NUMBER
    SET p_chicken_id = CONCAT(
        'F', LPAD(v_farm_id, 3, '0'),
        '-B', v_batch_number,
        '-C', LPAD(v_count, 4, '0')
    );
END //

-- Create stored procedure for adding new chicken with automatic ID
CREATE PROCEDURE add_new_chicken(
    IN p_batch_id INT,
    IN p_weight DECIMAL(5,2)
)
BEGIN
    DECLARE v_chicken_id VARCHAR(50);
    
    -- Generate chicken ID
    CALL generate_chicken_id(p_batch_id, v_chicken_id);
    
    -- Insert new chicken
    INSERT INTO chickens (
        batch_id,
        chicken_id,
        current_weight,
        age_days
    ) VALUES (
        p_batch_id,
        v_chicken_id,
        p_weight,
        0
    );
    
    -- Return the generated ID
    SELECT v_chicken_id AS generated_chicken_id;
END //

-- Create stored procedure for health analysis
CREATE PROCEDURE record_health_analysis(
    IN p_chicken_id INT,
    IN p_image_path VARCHAR(255),
    IN p_analysis_result TEXT,
    IN p_confidence_score DECIMAL(5,2),
    IN p_diagnosis VARCHAR(255)
)
BEGIN
    -- Insert health analysis record
    INSERT INTO health_analysis (
        chicken_id,
        image_path,
        analysis_result,
        confidence_score,
        diagnosis
    ) VALUES (
        p_chicken_id,
        p_image_path,
        p_analysis_result,
        p_confidence_score,
        p_diagnosis
    );
    
    -- Update chicken status if needed
    IF p_diagnosis != 'healthy' THEN
        UPDATE chickens 
        SET status = 'sick',
            last_checked = NOW()
        WHERE id = p_chicken_id;
        
        -- Create notification
        INSERT INTO notifications (
            user_id,
            title,
            message,
            type
        ) SELECT 
            f.user_id,
            'Health Alert',
            CONCAT('Chicken ', c.chicken_id, ' requires attention: ', p_diagnosis),
            'health_alert'
        FROM chickens c
        JOIN chicken_batches cb ON c.batch_id = cb.id
        JOIN farms f ON cb.farm_id = f.id
        WHERE c.id = p_chicken_id;
    END IF;
END //

DELIMITER ;

-- Create indexes for better performance
CREATE INDEX idx_chicken_id ON chickens(chicken_id);
CREATE INDEX idx_batch_chickens ON chickens(batch_id);
CREATE INDEX idx_health_analysis ON health_analysis(chicken_id);
CREATE INDEX idx_analysis_history ON analysis_history(chicken_id);
CREATE INDEX idx_daily_records ON daily_records(batch_id, date);
CREATE INDEX idx_treatment_records ON treatment_records(chicken_id);
CREATE INDEX idx_vaccination_schedule ON vaccination_schedule(batch_id, schedule_date);
CREATE INDEX idx_notifications ON notifications(user_id, is_read);

-- Insert default admin user
INSERT INTO users (
    first_name,
    last_name,
    email,
    password,
    role
) VALUES (
    'Admin',
    'User',
    'admin@bchi.com',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password: admin123
    'admin'
);
